<?php
// Silence is Golden
